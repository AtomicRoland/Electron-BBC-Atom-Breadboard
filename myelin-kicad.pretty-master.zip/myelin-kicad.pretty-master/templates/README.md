This folder contains snippets of Python code that can be pasted into netlist
scripts to quickly add components.
